# Afterglow Circuit — Progressive House

Komposisi instrumental orisinal dengan nuansa progressive house melodis dan atmosferik.
126 BPM | F minor | 4/4 | 160 bar | sekitar 5:04.76 | 12 layer.

## Impor ke DAW

1. Ekstrak ZIP ini, atur tempo 126 BPM dan meter 4/4.
2. Impor seluruh MIDI di midi/layers/ mulai bar 1/beat 1 ke track terpisah.
3. Pertahankan posisi diam pada file; instrumen masuk bertahap dalam aransemen.
4. Pilih kit electronic house untuk tujuh layer percussion. Mapping GM:
   kick 36, clap 39, snare 38, closed hat 42, open hat 46, ride 51,
   shaker/maracas 70. Tiap file drum memakai channel 10.
5. Pilih instrumen synth tersendiri untuk synth-bass, poly-synth, pluck-arp,
   warm-pad dan lead-synth. Tiap file melodic memakai channel 1.

## Arah sound

- Synth bass: mono, fundamental kuat, envelope pendek; biarkan ruang untuk kick.
- Poly synth: saw chords lebar, low-pass filter; buka cutoff bertahap menjelang drop.
- Pluck arp: envelope pendek, delay sinkron tempo; kurangi level saat lead masuk.
- Warm pad: attack pelan, reverb lebar, low-cut untuk menjaga low-end.
- Lead synth: saw melodis, sedikit detune, delay ringan.
- Atur sidechain bass/chord/pad dengan kick untuk gerakan pumping.

Filter automation, sidechain, stereo widening, delay/reverb dan riser audio
diatur di DAW; file MIDI berisi not, velocity dan pengaturan mixer awal.
Lagu memakai dua build/drop dan satu beat hening sebelum setiap drop.

summary.md berisi tautan semua MIDI, request.md berisi keputusan musik,
musical-review.md berisi audit event, verification.json berisi receipt CLI.
Semua 12 file lulus validate/generate/verify, satu track per file dan panjang sama.
Audio belum didengarkan.
