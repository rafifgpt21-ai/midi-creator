# Neon Step — New Jack Swing

108 BPM | F# minor | 4/4 | 96 bar | sekitar 3:33 | 15 layer.

1. Ekstrak arsip ini.
2. Atur project DAW ke 108 BPM dan meter 4/4.
3. Impor seluruh file di midi/layers/ pada bar 1, beat 1, masing-masing ke track terpisah.
4. Pertahankan keheningan di awal file; bass/gitar sengaja masuk setelah intro dimulai.
5. Pilih instrumen/preset sesuai nama layer. Gunakan kit drum machine, gated snare,
   slap bass, Rhodes, muted guitar, synth brass, saw synth lead, pad dan FM bell.
6. Drum memakai channel 10 dan mapping GM/GM2. Shaker memakai pitch 82 (GM2);
   pada kit lain, arahkan note 82 ke sample shaker. Instrumen bernada memakai
   channel 1 dalam file masing-masing dan perlu instrumen DAW tersendiri.
7. Timing swing 60:40 sudah ditulis pada event. Pertahankan timing saat impor.

summary.md memuat tautan ke 15 MIDI, request.md memuat keputusan dan mapping,
musical-review.md memuat audit musikal. composition.json adalah snapshot sumber.
validate/generate/verify lulus: satu track per file, panjang sama, tanpa overlap
pitch sama. MIDI berisi performa; audio belum didengarkan.
